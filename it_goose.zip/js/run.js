game.state.add("MainMenu", MainMenu);
game.state.add("Meeting", Meeting);
game.state.add("WaterCooler", WaterCooler);
game.state.add("TypeWriter", TypeWriter);
game.state.start("MainMenu");
